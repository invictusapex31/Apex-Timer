import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Task = {
  id: number;
  text: string;
  completed: boolean;
  dueDate?: string | null;
  createdAt: string;
};

interface EditTaskModalProps {
  task: Task;
  onSave: (id: number, text: string, dueDate: string | null) => void;
  onCancel: () => void;
}

export default function EditTaskModal({ task, onSave, onCancel }: EditTaskModalProps) {
  const [text, setText] = useState(task.text);
  const [dueDate, setDueDate] = useState<string | null>(task.dueDate || null);

  const formatDateTimeForInput = (dateString: string | null) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toISOString().slice(0, 16); // Format as YYYY-MM-DDThh:mm
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (text.trim() === "") return;
    
    onSave(task.id, text, dueDate);
  };

  return (
    <Dialog open={true} onOpenChange={() => onCancel()}>
      <DialogContent className="bg-neutral-800 border border-neutral-700/50 text-white">
        <DialogHeader>
          <DialogTitle>Edit Task</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="task-text" className="text-sm font-medium text-neutral-400/80">
                Task Description
              </Label>
              <Input
                id="task-text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="bg-neutral-900/70 text-white border-neutral-700 focus:ring-green-500/50"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="due-date" className="text-sm font-medium text-neutral-400/80">
                Due Date (Optional)
              </Label>
              <Input
                id="due-date"
                type="datetime-local"
                value={formatDateTimeForInput(dueDate)}
                onChange={(e) => setDueDate(e.target.value || null)}
                className="bg-neutral-900/70 text-white border-neutral-700 focus:ring-green-500/50"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button
              type="button"
              variant="secondary"
              onClick={onCancel}
              className="bg-neutral-700 hover:bg-neutral-600 text-white"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

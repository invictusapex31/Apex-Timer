import { Link, useLocation } from "wouter";
import { Clock, ListTodo, Info } from "lucide-react";

export function Header() {
  const [location] = useLocation();
  
  return (
    <header className="py-4 px-4 mb-8 backdrop-blur-md bg-background/50 border-b border-primary/10 shadow-sm animate-slide-in-up">
      <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <div className="w-12 h-12 rounded-full bg-premium-gradient flex items-center justify-center mr-3 shadow-premium animate-pulse-glow">
            <span className="text-xl font-bold premium-text tracking-wider text-white">IA</span>
          </div>
          <h1 className="text-2xl font-bold premium-header bg-clip-text text-transparent bg-premium-gradient-animate bg-[size:200%_200%] animate-gradient-shift">
            INVICTUS APEX
          </h1>
        </div>
        

        
        <nav className="glass-card py-2 px-4 rounded-full">
          <ul className="flex space-x-8">
            <li>
              <Link href="/" className={`${location === '/' ? 'text-primary font-medium' : 'text-foreground/70 hover:text-primary'} transition-colors duration-300 flex items-center`}>
                <Clock className="w-4 h-4 mr-2" />
                <span className="premium-text">Timer</span>
              </Link>
            </li>
            <li>
              <Link href="/" className={`text-foreground/70 hover:text-primary transition-colors duration-300 flex items-center`}>
                <ListTodo className="w-4 h-4 mr-2" />
                <span className="premium-text">Tasks</span>
              </Link>
            </li>
            <li>
              <Link href="/contact" className={`${location === '/contact' ? 'text-primary font-medium' : 'text-foreground/70 hover:text-primary'} transition-colors duration-300 flex items-center`}>
                <Info className="w-4 h-4 mr-2" />
                <span className="premium-text">Contact</span>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

import { Check, Edit, Trash2, Calendar, Clock, AlertCircle } from "lucide-react";

type Task = {
  id: number;
  text: string;
  completed: boolean;
  dueDate?: string | null;
  createdAt: string;
};

interface TaskItemProps {
  task: Task;
  onToggleStatus: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export default function TaskItem({ task, onToggleStatus, onEdit, onDelete }: TaskItemProps) {
  // Format due date
  const formatDueDate = () => {
    if (!task.dueDate) return null;
    
    const dueDate = new Date(task.dueDate);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (dueDate.toDateString() === today.toDateString()) {
      return `Today at ${dueDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    } else if (dueDate.toDateString() === tomorrow.toDateString()) {
      return `Tomorrow at ${dueDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    } else {
      return `${dueDate.toLocaleDateString()} at ${dueDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    }
  };

  // Check if task is overdue
  const isOverdue = () => {
    if (!task.dueDate || task.completed) return false;
    const dueDate = new Date(task.dueDate);
    const now = new Date();
    return dueDate < now;
  };

  // Due date styling
  const getDueDateStyle = () => {
    if (task.completed) return "text-muted-foreground/50";
    if (isOverdue()) return "text-destructive/90 font-medium";
    return "text-muted-foreground/80";
  };

  return (
    <div 
      className={`task-item bg-background/40 backdrop-blur-xs rounded-xl p-4 flex items-center space-x-3 group transition-all duration-300 
        ${task.completed 
          ? 'border border-primary/5 hover:border-primary/10' 
          : 'subtle-border hover:border-primary/20'} 
        ${task.completed ? 'opacity-80' : 'hover:shadow-premium'}
      `}
    >
      <button 
        className={`w-6 h-6 rounded-full flex items-center justify-center transition-all duration-300
          ${task.completed 
            ? 'bg-primary/20 border border-primary/30' 
            : 'border-2 border-primary/40 hover:border-primary hover:bg-primary/10'}
        `}
        onClick={onToggleStatus}
        aria-label={task.completed ? "Mark as incomplete" : "Mark as complete"}
      >
        <Check 
          className={`h-3.5 w-3.5 transition-opacity duration-300
            ${task.completed ? 'text-primary opacity-100' : 'text-primary opacity-0'}
          `} 
        />
      </button>
      
      <div className="flex-1">
        <p className={`premium-text transition-all duration-300 ${
          task.completed 
            ? 'text-muted-foreground/60 line-through' 
            : isOverdue()
              ? 'text-foreground'
              : 'text-foreground'
        }`}>
          {task.text}
        </p>
        
        {task.dueDate && (
          <div className={`flex items-center text-xs mt-1.5 ${getDueDateStyle()}`}>
            {task.completed ? (
              <>
                <Check className="h-3 w-3 mr-1 text-primary/70" />
                <span>Completed</span>
              </>
            ) : isOverdue() ? (
              <>
                <AlertCircle className="h-3 w-3 mr-1 text-destructive" />
                <span>Overdue: {formatDueDate()}</span>
              </>
            ) : (
              <>
                <Calendar className="h-3 w-3 mr-1" />
                <span>Due: {formatDueDate()}</span>
              </>
            )}
          </div>
        )}
      </div>
      
      <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-all duration-300">
        <button
          className="p-1.5 text-muted-foreground hover:text-primary rounded-full hover:bg-background/70 transition-colors"
          onClick={onEdit}
          aria-label="Edit task"
        >
          <Edit className="h-3.5 w-3.5" />
        </button>
        <button
          className="p-1.5 text-muted-foreground hover:text-destructive rounded-full hover:bg-background/70 transition-colors"
          onClick={onDelete}
          aria-label="Delete task"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

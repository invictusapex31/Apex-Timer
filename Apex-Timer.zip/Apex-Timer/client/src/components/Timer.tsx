import { useState, useEffect, useRef, forwardRef, useImperativeHandle } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import TimerCompleteModal from "./TimerCompleteModal";
import { Play, Pause, RotateCcw, Clock, Timer as TimerIcon, Clock4, Maximize, Minimize, X } from "lucide-react";
import { playAlarmSound } from "@/lib/sounds";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import "./TimerStyles.css";

// Define TimerSettings type
interface TimerSettings {
  id: number;
  userId: number | null;
  defaultMinutes: number;
  defaultSeconds: number;
  alarmSound: string;
  volume: number;
  autoStartBreak: boolean;
  timerMode: string;
  pomodoroMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakInterval: number;
  autoStartPomodoro: boolean;
}

interface TimerProps {
  onTimerComplete: () => void;
}

// Define the ref type
export interface TimerRef {
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: () => void;
}

// Pomodoro timer states
type PomodoroState = "pomodoro" | "shortBreak" | "longBreak";

export default forwardRef<TimerRef, TimerProps>(function Timer({ onTimerComplete }, ref) {
  // Basic timer state
  const [hours, setHours] = useState<number>(0);
  const [minutes, setMinutes] = useState<number>(25);
  const [seconds, setSeconds] = useState<number>(0);
  const [remainingSeconds, setRemainingSeconds] = useState<number>(25 * 60);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [showTimerCompleteModal, setShowTimerCompleteModal] = useState<boolean>(false);
  const [timerStatus, setTimerStatus] = useState<string>("Ready to start");
  
  // Timer mode state
  const [timerMode, setTimerMode] = useState<"pomodoro" | "countdown" | "stopwatch">("pomodoro");
  
  // Pomodoro specific state
  const [pomodoroState, setPomodoroState] = useState<PomodoroState>("pomodoro");
  const [pomodoroCount, setPomodoroCount] = useState<number>(0);
  
  // Stopwatch specific state
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [studySessionId, setStudySessionId] = useState<number | null>(null);
  const [category, setCategory] = useState<string>("General");
  
  // Refs
  const timerProgressRef = useRef<SVGCircleElement>(null);
  const timerInterval = useRef<NodeJS.Timeout | null>(null);
  const timerContainerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Fullscreen state
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Expose methods via ref
  useImperativeHandle(ref, () => ({
    startTimer,
    pauseTimer,
    resetTimer
  }));

  // Get timer settings
  const { data: timerSettings } = useQuery<TimerSettings>({
    queryKey: ['/api/timer-settings'],
  });

  // Update timer settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", "/api/timer-settings", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/timer-settings'] });
    },
  });

  // Initialize timer based on settings
  useEffect(() => {
    if (timerSettings) {
      const mode = (timerSettings.timerMode as "pomodoro" | "countdown" | "stopwatch") || "pomodoro";
      setTimerMode(mode);
      
      if (mode === "countdown") {
        const defaultHours = Math.floor(timerSettings.defaultMinutes / 60);
        const defaultMinutes = timerSettings.defaultMinutes % 60;
        const defaultSeconds = timerSettings.defaultSeconds || 0;
        
        setHours(defaultHours);
        setMinutes(defaultMinutes);
        setSeconds(defaultSeconds);
        
        // Calculate the total remaining seconds for countdown mode
        const totalSeconds = (defaultHours * 3600) + (defaultMinutes * 60) + defaultSeconds;
        setRemainingSeconds(totalSeconds);
      } else if (mode === "pomodoro") {
        // For pomodoro mode, set the correct current session time
        let pomodoroMinutes = 25;
        if (pomodoroState === "pomodoro") {
          pomodoroMinutes = timerSettings.pomodoroMinutes || 25;
        } else if (pomodoroState === "shortBreak") {
          pomodoroMinutes = timerSettings.shortBreakMinutes || 5;
        } else {
          pomodoroMinutes = timerSettings.longBreakMinutes || 15;
        }
        
        setMinutes(pomodoroMinutes);
        setSeconds(0);
        setHours(0);
        
        // Calculate the total remaining seconds for pomodoro mode
        setRemainingSeconds(pomodoroMinutes * 60);
      } else if (mode === "stopwatch") {
        // For stopwatch mode, reset everything
        setHours(0);
        setMinutes(0);
        setSeconds(0);
        setElapsedSeconds(0);
        setRemainingSeconds(0);
      }
    }
  }, [timerSettings, pomodoroState]);

  // Format timer display
  const formatTime = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    
    if (hrs > 0 || timerMode === "countdown") {
      return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
  };

  // Handle hours input change
  const handleHoursChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    let newHours;
    
    if (isNaN(value) || value < 0) {
      newHours = 0;
    } else if (value > 23) {
      newHours = 23;
    } else {
      newHours = value;
    }
    
    setHours(newHours);
    
    // Update remaining seconds if in countdown mode and not running
    if (timerMode === "countdown" && !isRunning) {
      const mins = minutes || 0;
      const secs = seconds || 0;
      const totalSeconds = (newHours * 3600) + (mins * 60) + secs;
      setRemainingSeconds(totalSeconds);
      
      // Update settings for countdown timer
      // Calculate total minutes for storage (hours * 60 + minutes)
      const totalMinutesForSettings = (newHours * 60) + mins;
      updateSettingsMutation.mutate({ 
        defaultMinutes: totalMinutesForSettings 
      });
    }
  };

  // Handle minutes input change
  const handleMinutesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    let newMinutes;
    
    if (isNaN(value) || value < 0) {
      newMinutes = 0;
    } else if (value > 59) {
      newMinutes = 59;
    } else {
      newMinutes = value;
    }
    
    setMinutes(newMinutes);
    
    // Update remaining seconds based on the timer mode
    if (!isRunning) {
      if (timerMode === "countdown") {
        const hrs = hours || 0;
        const secs = seconds || 0;
        const totalSeconds = (hrs * 3600) + (newMinutes * 60) + secs;
        setRemainingSeconds(totalSeconds);
        
        // Update settings for countdown timer
        // Calculate total minutes for storage (hours * 60 + minutes)
        const totalMinutesForSettings = (hrs * 60) + newMinutes;
        updateSettingsMutation.mutate({ 
          defaultMinutes: totalMinutesForSettings 
        });
      } else if (timerMode === "pomodoro") {
        const secs = seconds || 0;
        const totalSeconds = (newMinutes * 60) + secs;
        setRemainingSeconds(totalSeconds);
        
        // Update different pomodoro settings based on current state
        if (pomodoroState === "pomodoro") {
          updateSettingsMutation.mutate({ 
            pomodoroMinutes: newMinutes 
          });
        } else if (pomodoroState === "shortBreak") {
          updateSettingsMutation.mutate({ 
            shortBreakMinutes: newMinutes 
          });
        } else if (pomodoroState === "longBreak") {
          updateSettingsMutation.mutate({ 
            longBreakMinutes: newMinutes 
          });
        }
      }
    }
  };

  // Handle seconds input change
  const handleSecondsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    let newSeconds;
    
    if (isNaN(value) || value < 0) {
      newSeconds = 0;
    } else if (value > 59) {
      newSeconds = 59;
    } else {
      newSeconds = value;
    }
    
    setSeconds(newSeconds);
    
    // Update remaining seconds based on the timer mode
    if (!isRunning) {
      if (timerMode === "countdown") {
        const hrs = hours || 0;
        const mins = minutes || 0;
        const totalSeconds = (hrs * 3600) + (mins * 60) + newSeconds;
        setRemainingSeconds(totalSeconds);
        
        // Update default seconds for countdown timer
        updateSettingsMutation.mutate({ 
          defaultSeconds: newSeconds 
        });
      } else {
        // For pomodoro mode
        const mins = minutes || 0;
        const totalSeconds = (mins * 60) + newSeconds;
        setRemainingSeconds(totalSeconds);
      }
    }
  };

  // Handle timer mode change
  const handleTimerModeChange = (value: "pomodoro" | "countdown" | "stopwatch") => {
    if (isRunning) {
      pauseTimer();
    }
    
    setTimerMode(value);
    
    // Update timer mode in settings first
    updateSettingsMutation.mutate(
      { timerMode: value },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['/api/timer-settings'] });
          
          // Apply mode-specific settings after updating the database
          if (value === "pomodoro") {
            setPomodoroState("pomodoro");
            if (timerSettings) {
              setMinutes(timerSettings.pomodoroMinutes || 25);
              setSeconds(0);
              setHours(0);
            } else {
              setMinutes(25);
              setSeconds(0);
              setHours(0);
            }
            
            // Update remaining seconds
            const pomodoroMins = timerSettings?.pomodoroMinutes || 25;
            setRemainingSeconds(pomodoroMins * 60);
          } else if (value === "countdown") {
            // For countdown mode, set values from settings
            if (timerSettings) {
              const defaultHours = Math.floor(timerSettings.defaultMinutes / 60);
              const defaultMinutes = timerSettings.defaultMinutes % 60;
              const defaultSeconds = timerSettings.defaultSeconds || 0;
              
              setHours(defaultHours);
              setMinutes(defaultMinutes);
              setSeconds(defaultSeconds);
              
              // Update remaining seconds
              const totalSeconds = (defaultHours * 3600) + (defaultMinutes * 60) + defaultSeconds;
              setRemainingSeconds(totalSeconds);
            } else {
              // Default values if no settings
              setHours(0);
              setMinutes(25);
              setSeconds(0);
              setRemainingSeconds(25 * 60);
            }
          } else if (value === "stopwatch") {
            // For stopwatch, reset everything to zero
            setHours(0);
            setMinutes(0);
            setSeconds(0);
            setElapsedSeconds(0);
            setRemainingSeconds(0);
            setStudySessionId(null);
          }
        }
      }
    );
    
    // Do not call resetTimer() here as it will recalculate and overwrite our values
    pauseTimer();
    setTimerStatus("Ready to start");
    
    if (timerProgressRef.current) {
      timerProgressRef.current.classList.remove('countdown-active');
      timerProgressRef.current.style.strokeDashoffset = '0';
    }
  };

  // Handle pomodoro state change
  const handlePomodoroStateChange = (state: PomodoroState) => {
    if (isRunning) {
      pauseTimer();
    }
    
    setPomodoroState(state);
    
    if (state === "pomodoro" && timerSettings) {
      setMinutes(timerSettings.pomodoroMinutes || 25);
      setSeconds(0);
    } else if (state === "shortBreak" && timerSettings) {
      setMinutes(timerSettings.shortBreakMinutes || 5);
      setSeconds(0);
    } else if (state === "longBreak" && timerSettings) {
      setMinutes(timerSettings.longBreakMinutes || 15);
      setSeconds(0);
    }
    
    resetTimer();
  };

  // Create study session mutation
  const createStudySessionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/study-sessions", data);
      return response.json();
    },
    onSuccess: (data) => {
      setStudySessionId(data.id);
    },
  });
  
  // Update study session mutation
  const updateStudySessionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      const response = await apiRequest("PUT", `/api/study-sessions/${id}`, data);
      return response.json();
    },
  });
  
  // Start timer
  const startTimer = () => {
    if (isRunning) return;
    
    if (timerMode === "stopwatch") {
      startStopwatch();
      return;
    }
    
    if (remainingSeconds <= 0) {
      const hrs = hours || 0;
      const mins = minutes || 0;
      const secs = seconds || 0;
      const totalSeconds = (hrs * 3600) + (mins * 60) + secs;
      
      if (totalSeconds <= 0) {
        toast({
          title: "Invalid time",
          description: "Please set a time greater than zero",
          variant: "destructive",
        });
        return;
      }
      
      setRemainingSeconds(totalSeconds);
    }
    
    setIsRunning(true);
    setTimerStatus("Running...");
    
    // Set animation duration
    if (timerProgressRef.current) {
      timerProgressRef.current.style.setProperty('--duration', `${remainingSeconds}s`);
      timerProgressRef.current.classList.add('countdown-active');
    }
    
    timerInterval.current = setInterval(() => {
      setRemainingSeconds((prev) => {
        if (prev <= 1) {
          completeTimer();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };
  
  // Start stopwatch
  const startStopwatch = () => {
    // Reset elapsed time if starting fresh
    if (!isRunning && elapsedSeconds === 0) {
      setElapsedSeconds(0);
      
      // Create a new study session
      createStudySessionMutation.mutate({
        userId: null,
        startTime: new Date(),
        timerType: "stopwatch",
        tags: [category],
        completed: false
      });
    }
    
    setIsRunning(true);
    setTimerStatus("Running...");
    
    timerInterval.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
      setRemainingSeconds(prev => prev + 1);
    }, 1000);
  };

  // Pause timer
  const pauseTimer = () => {
    if (!isRunning) return;
    
    setIsRunning(false);
    setTimerStatus("Paused");
    
    // Pause animation
    if (timerProgressRef.current) {
      const dashOffset = getComputedStyle(timerProgressRef.current).strokeDashoffset;
      timerProgressRef.current.classList.remove('countdown-active');
      timerProgressRef.current.style.strokeDashoffset = dashOffset;
    }
    
    if (timerInterval.current) {
      clearInterval(timerInterval.current);
      timerInterval.current = null;
    }
    
    // For stopwatch, update study session on pause
    if (timerMode === "stopwatch" && studySessionId) {
      updateStudySessionMutation.mutate({
        id: studySessionId,
        data: {
          duration: elapsedSeconds
        }
      });
    }
  };

  // Reset timer
  const resetTimer = () => {
    pauseTimer();
    
    if (timerMode === "stopwatch") {
      // For stopwatch, mark the session as completed if it was running
      if (studySessionId && elapsedSeconds > 0) {
        updateStudySessionMutation.mutate({
          id: studySessionId,
          data: {
            duration: elapsedSeconds,
            completed: true,
            endTime: new Date()
          }
        });
        
        // Also track study time via increaseStudyTime endpoint
        if (elapsedSeconds > 0) {
          apiRequest("POST", "/api/study-stats/increase-time", {
            seconds: elapsedSeconds,
            category: category
          });
        }
      }
      
      // Reset elapsed time and session ID
      setElapsedSeconds(0);
      setRemainingSeconds(0);
      setStudySessionId(null);
    } else {
      let totalSeconds;
      if (timerMode === "countdown") {
        const hrs = hours || 0;
        const mins = minutes || 0;
        const secs = seconds || 0;
        totalSeconds = (hrs * 3600) + (mins * 60) + secs;
      } else {
        // For pomodoro mode
        const mins = minutes || 0;
        const secs = seconds || 0;
        totalSeconds = (mins * 60) + secs;
      }
      
      setRemainingSeconds(totalSeconds);
    }
    
    setTimerStatus("Ready to start");
    
    if (timerProgressRef.current) {
      timerProgressRef.current.classList.remove('countdown-active');
      timerProgressRef.current.style.strokeDashoffset = '0';
    }
  };

  // Complete timer
  const completeTimer = () => {
    if (timerInterval.current) {
      clearInterval(timerInterval.current);
      timerInterval.current = null;
    }
    
    setIsRunning(false);
    setRemainingSeconds(0);
    setTimerStatus("Completed!");
    
    if (timerSettings) {
      playAlarmSound(timerSettings.alarmSound, timerSettings.volume / 100);
    } else {
      playAlarmSound("bell", 0.8);
    }
    
    // Pomodoro logic
    if (timerMode === "pomodoro") {
      if (pomodoroState === "pomodoro") {
        // Increment pomodoro count when a pomodoro session is completed
        const newCount = pomodoroCount + 1;
        setPomodoroCount(newCount);
        
        // Check if we should take a long break
        if (timerSettings && newCount % (timerSettings.longBreakInterval || 4) === 0) {
          setPomodoroState("longBreak");
          setMinutes(timerSettings.longBreakMinutes || 15);
          setSeconds(0);
          
          // Auto-start the break if setting is enabled
          if (timerSettings.autoStartBreak) {
            setTimeout(() => {
              resetTimer();
              startTimer();
            }, 1000);
          }
        } else {
          // Otherwise take a short break
          setPomodoroState("shortBreak");
          setMinutes(timerSettings?.shortBreakMinutes || 5);
          setSeconds(0);
          
          // Auto-start the break if setting is enabled
          if (timerSettings?.autoStartBreak) {
            setTimeout(() => {
              resetTimer();
              startTimer();
            }, 1000);
          }
        }
      } else {
        // If a break is completed, start the next pomodoro
        setPomodoroState("pomodoro");
        setMinutes(timerSettings?.pomodoroMinutes || 25);
        setSeconds(0);
        
        // Auto-start the pomodoro if setting is enabled
        if (timerSettings?.autoStartPomodoro) {
          setTimeout(() => {
            resetTimer();
            startTimer();
          }, 1000);
        }
      }
    }
    
    setShowTimerCompleteModal(true);
    onTimerComplete();
  };

  // Handle start next session (break or pomodoro)
  const handleStartNextSession = () => {
    setShowTimerCompleteModal(false);
    resetTimer();
    startTimer();
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerInterval.current) {
        clearInterval(timerInterval.current);
      }
    };
  }, []);

  // Update timer inputs when not running
  useEffect(() => {
    if (!isRunning) {
      let totalSeconds = 0;
      
      if (timerMode === "countdown") {
        const hrs = hours || 0;
        const mins = minutes || 0;
        const secs = seconds || 0;
        totalSeconds = (hrs * 3600) + (mins * 60) + secs;
      } else {
        const mins = minutes || 0;
        const secs = seconds || 0;
        totalSeconds = (mins * 60) + secs;
      }
      
      setRemainingSeconds(totalSeconds);
    }
  }, [hours, minutes, seconds, isRunning, timerMode]);

  // Get the timer title based on mode/state
  const getTimerTitle = () => {
    if (timerMode === "countdown") {
      return "Countdown Timer";
    } else if (timerMode === "stopwatch") {
      return "Study Tracker";
    } else {
      if (pomodoroState === "pomodoro") {
        return "Focus Time";
      } else if (pomodoroState === "shortBreak") {
        return "Short Break";
      } else {
        return "Long Break";
      }
    }
  };
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!isFullscreen) {
      enterFullscreen();
    } else {
      exitFullscreen();
    }
  };
  
  // Enter fullscreen
  const enterFullscreen = () => {
    const element = timerContainerRef.current;
    if (!element) return;
    
    if (element.requestFullscreen) {
      element.requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(err => {
          toast({
            title: "Fullscreen error",
            description: `Error entering fullscreen mode: ${err.message}`,
            variant: "destructive",
          });
        });
    } else if ((element as any).webkitRequestFullscreen) {
      (element as any).webkitRequestFullscreen();
      setIsFullscreen(true);
    } else if ((element as any).msRequestFullscreen) {
      (element as any).msRequestFullscreen();
      setIsFullscreen(true);
    }
  };
  
  // Exit fullscreen
  const exitFullscreen = () => {
    if (document.exitFullscreen) {
      document.exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(err => {
          toast({
            title: "Fullscreen error",
            description: `Error exiting fullscreen mode: ${err.message}`,
            variant: "destructive",
          });
        });
    } else if ((document as any).webkitExitFullscreen) {
      (document as any).webkitExitFullscreen();
      setIsFullscreen(false);
    } else if ((document as any).msExitFullscreen) {
      (document as any).msExitFullscreen();
      setIsFullscreen(false);
    }
  };
  
  // Handler for fullscreen change event
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement || !!(document as any).webkitFullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);

  // Get the timer icon based on mode/state
  const getTimerIcon = () => {
    if (timerMode === "countdown") {
      return <Clock className="h-5 w-5 mr-2 text-primary" />;
    } else if (timerMode === "stopwatch") {
      return <Clock4 className="h-5 w-5 mr-2 text-emerald-500" />;
    } else {
      if (pomodoroState === "pomodoro") {
        return <TimerIcon className="h-5 w-5 mr-2 text-primary" />;
      } else {
        return <Clock4 className="h-5 w-5 mr-2 text-accent" />;
      }
    }
  };

  return (
    <>
      <Card className="bg-neutral-900/50 backdrop-blur-lg shadow-xl border-neutral-800">
        <CardContent className="p-4 sm:p-6 md:p-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold flex items-center">
              {getTimerIcon()}
              {getTimerTitle()}
            </h2>
            
            <div className="flex items-center gap-1 xs:gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 xs:h-8 xs:w-8 rounded-full bg-neutral-800/30 hover:bg-neutral-800/50 text-white"
                onClick={toggleFullscreen}
                title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
              >
                {isFullscreen ? <Minimize className="h-3 w-3 xs:h-4 xs:w-4" /> : <Maximize className="h-3 w-3 xs:h-4 xs:w-4" />}
              </Button>
              
              <Select value={timerMode} onValueChange={(val: any) => handleTimerModeChange(val)}>
                <SelectTrigger className="w-[110px] xs:w-40 h-7 xs:h-8 text-xs xs:text-sm bg-neutral-800/70 border-neutral-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pomodoro">Pomodoro</SelectItem>
                  <SelectItem value="countdown">Countdown</SelectItem>
                  <SelectItem value="stopwatch">Stopwatch</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Pomodoro Tabs - Only shown in pomodoro mode */}
          {timerMode === "pomodoro" && (
            <div className="mb-6">
              <Tabs defaultValue="pomodoro" value={pomodoroState} 
                onValueChange={(value) => handlePomodoroStateChange(value as PomodoroState)}>
                <TabsList className="w-full bg-neutral-800/70 text-white">
                  <TabsTrigger 
                    value="pomodoro" 
                    className="flex-1 data-[state=active]:bg-primary text-xs xs:text-sm font-medium py-2"
                  >
                    <span className="hidden xs:inline">Pomodoro</span>
                    <span className="inline xs:hidden">Focus</span>
                    <Badge variant="secondary" className="ml-1 xs:ml-2 bg-primary/30 text-white text-xs">
                      {pomodoroCount}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="shortBreak" 
                    className="flex-1 data-[state=active]:bg-accent text-xs xs:text-sm font-medium py-2"
                  >
                    <span className="hidden xs:inline">Short Break</span>
                    <span className="inline xs:hidden">Short</span>
                  </TabsTrigger>
                  <TabsTrigger 
                    value="longBreak" 
                    className="flex-1 data-[state=active]:bg-purple-600 text-xs xs:text-sm font-medium py-2"
                  >
                    <span className="hidden xs:inline">Long Break</span>
                    <span className="inline xs:hidden">Long</span>
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          )}
          
          {/* Study Category - Only shown in stopwatch mode */}
          {timerMode === "stopwatch" && (
            <div className="mb-6">
              <label className="block text-sm font-medium text-neutral-400/80 mb-2">
                Study Category
              </label>
              <Select value={category} onValueChange={setCategory} disabled={isRunning}>
                <SelectTrigger className="w-full h-10 text-sm bg-neutral-800/70 border-neutral-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="General">General</SelectItem>
                  <SelectItem value="Math">Math</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                  <SelectItem value="Language">Language</SelectItem>
                  <SelectItem value="History">History</SelectItem>
                  <SelectItem value="Computer Science">Computer Science</SelectItem>
                  <SelectItem value="Arts">Arts</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
          
          {/* Timer Display */}
          <div className="flex justify-center mb-4 sm:mb-8">
            <div 
              ref={timerContainerRef}
              className={`timer-container relative w-72 h-72 xs:w-72 xs:h-72 sm:w-96 sm:h-96 md:w-[28rem] md:h-[28rem] lg:w-[30rem] lg:h-[30rem] flex items-center justify-center ${isFullscreen ? 'fixed inset-0 w-full h-full z-50 bg-background/95' : ''}`}
            >
              {/* Fullscreen close button - only shown when in fullscreen mode */}
              {isFullscreen && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-4 right-4 z-50 h-10 w-10 rounded-full bg-neutral-800/50 hover:bg-neutral-700/70 text-white"
                  onClick={exitFullscreen}
                  title="Exit fullscreen"
                >
                  <X className="h-5 w-5" />
                </Button>
              )}
              {/* Decorative elements */}
              <div className="absolute inset-0 bg-premium-gradient-animate bg-[size:400%_400%] animate-gradient-shift opacity-5 rounded-full blur-xl"></div>
              
              {/* Outer glow ring */}
              <div className={`absolute w-full h-full timer-circle-outer ${isRunning ? 'timer-active-glow' : ''}`}>
                <svg className="w-full h-full" viewBox="0 0 100 100">
                  <circle 
                    className={`timer-circle-background ${isRunning ? 'pulse' : ''}`}
                    strokeWidth="1" 
                    stroke="currentColor"
                    fill={`rgba(var(--primary-rgb), 0.03)`}
                    r="48" 
                    cx="50" 
                    cy="50"
                  />
                </svg>
              </div>
              
              {/* Background Circle */}
              <svg className="absolute w-full h-full" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="circleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="rgba(var(--primary-rgb), 0.1)" />
                    <stop offset="100%" stopColor="rgba(var(--primary-rgb), 0.05)" />
                  </linearGradient>
                </defs>
                <circle 
                  className="opacity-30" 
                  strokeWidth="4" 
                  stroke="url(#circleGradient)" 
                  fill="transparent" 
                  r="45" 
                  cx="50" 
                  cy="50"
                />
                
                {/* Tick marks for realistic clock effect */}
                {[...Array(12)].map((_, i) => (
                  <line 
                    key={i}
                    x1="50"
                    y1="10"
                    x2="50"
                    y2="15"
                    stroke="rgba(var(--primary-rgb), 0.2)"
                    strokeWidth="1"
                    transform={`rotate(${i * 30} 50 50)`}
                  />
                ))}
                
                {/* Hour markers */}
                {[...Array(4)].map((_, i) => (
                  <line 
                    key={i}
                    x1="50"
                    y1="8"
                    x2="50"
                    y2="15"
                    stroke="rgba(var(--primary-rgb), 0.4)"
                    strokeWidth="1.5"
                    transform={`rotate(${i * 90} 50 50)`}
                  />
                ))}
              </svg>
              
              {/* Progress Circle with rounded caps for smoothness */}
              <svg className={`absolute w-full h-full ${isRunning ? 'timer-tick' : ''}`} viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="rgba(var(--primary-rgb), 1)" />
                    <stop offset="100%" stopColor="rgba(var(--primary-rgb), 0.8)" />
                  </linearGradient>
                </defs>
                <circle 
                  ref={timerProgressRef}
                  className={`countdown-circle ${
                    timerMode === 'pomodoro' 
                      ? pomodoroState === 'pomodoro' 
                        ? 'text-primary' 
                        : pomodoroState === 'shortBreak' 
                          ? 'text-accent' 
                          : 'text-purple-600'
                      : timerMode === 'stopwatch'
                        ? 'text-emerald-500'
                        : 'text-primary'
                  }`}
                  strokeWidth="5" 
                  stroke="url(#progressGradient)" 
                  fill="transparent" 
                  r="45" 
                  cx="50" 
                  cy="50"
                />
              </svg>
              
              {/* Inner fill for more depth */}
              <div className="absolute w-56 h-56 xs:w-56 xs:h-56 sm:w-80 sm:h-80 md:w-[22rem] md:h-[22rem] lg:w-[24rem] lg:h-[24rem] rounded-full bg-background/80 backdrop-blur-sm shadow-inner flex items-center justify-center">
                <div className="absolute inset-0 rounded-full opacity-10 bg-premium-gradient"></div>
                
                {/* Timer Text */}
                <div className="text-center relative z-10">
                  <div className={`timer-led-display ${
                    timerMode === 'countdown' && hours > 0 
                      ? 'text-3xl xs:text-3xl sm:text-5xl md:text-5xl lg:text-6xl' 
                      : 'text-4xl xs:text-4xl sm:text-6xl md:text-6xl lg:text-7xl'
                  } font-bold tracking-tight ${isRunning ? 'timer-finish' : ''}`}>
                    {formatTime(remainingSeconds).split('').map((char, index) => 
                      char === ':' ? (
                        <span key={index} className="timer-led-colon">:</span>
                      ) : (
                        <span key={index}>{char}</span>
                      )
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground mt-3 premium-text">
                    {timerStatus}
                  </div>
                </div>
              </div>
              
              {/* Additional visual elements for better UX */}
              {isRunning && (
                <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-primary animate-pulse flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-primary-foreground"></div>
                </div>
              )}
            </div>
          </div>
          
          {/* Timer Controls */}
          {timerMode !== 'stopwatch' && (
            <div className={`grid ${timerMode === 'countdown' ? 'grid-cols-3' : 'grid-cols-2'} gap-4 mb-6`}>
              {timerMode === 'countdown' && (
                <div>
                  <label className="block text-sm font-medium text-neutral-400/80 mb-1">
                    Hours
                  </label>
                  <Input
                    type="number"
                    min="0"
                    max="23"
                    value={hours}
                    onChange={handleHoursChange}
                    className="timer-input w-full bg-neutral-900/50 text-white border-neutral-700 focus:ring-primary/50"
                    disabled={isRunning}
                  />
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-neutral-400/80 mb-1">
                  Minutes
                </label>
                <Input
                  type="number"
                  min="0"
                  max={timerMode === 'countdown' ? '59' : '180'}
                  value={minutes}
                  onChange={handleMinutesChange}
                  className="timer-input w-full bg-neutral-900/50 text-white border-neutral-700 focus:ring-primary/50"
                  disabled={isRunning || (timerMode === 'pomodoro' && pomodoroState !== 'pomodoro')}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-neutral-400/80 mb-1">
                  Seconds
                </label>
                <Input
                  type="number"
                  min="0"
                  max="59"
                  value={seconds}
                  onChange={handleSecondsChange}
                  className="timer-input w-full bg-neutral-900/50 text-white border-neutral-700 focus:ring-primary/50"
                  disabled={isRunning}
                />
              </div>
            </div>
          )}
          
          {/* Stopwatch Stats */}
          {timerMode === 'stopwatch' && (
            <div className="mb-6">
              <div className="flex justify-between p-3 mb-3 bg-neutral-800/30 rounded-md border border-neutral-700/50">
                <div className="text-sm text-neutral-300">Current Session:</div>
                <div className="text-sm font-medium text-emerald-400">{formatTime(elapsedSeconds)}</div>
              </div>
              
              <div className="flex justify-between p-3 bg-neutral-800/30 rounded-md border border-neutral-700/50">
                <div className="text-sm text-neutral-300">Category:</div>
                <div className="text-sm font-medium text-emerald-400">{category}</div>
              </div>
            </div>
          )}
          
          {/* Timer Action Buttons */}
          <div className="flex justify-center mt-2">
            <div className="grid grid-cols-3 gap-2 w-full">
              <Button
                variant="default"
                className={`premium-button col-span-3 xs:col-span-3 sm:col-span-2 button-bounce px-3 py-3 xs:px-4 xs:py-4 sm:px-6 sm:py-6 rounded-xl shadow-lg transition-all duration-300 flex items-center justify-center ${
                  timerMode === 'pomodoro' 
                    ? pomodoroState === 'pomodoro' 
                      ? 'bg-premium-gradient hover:shadow-premium-hover' 
                      : pomodoroState === 'shortBreak' 
                        ? 'bg-accent hover:bg-accent/80 hover:shadow-premium-hover' 
                        : 'bg-purple-600 hover:bg-purple-700 hover:shadow-premium-hover'
                    : timerMode === 'stopwatch'
                      ? 'bg-emerald-500 hover:bg-emerald-600 hover:shadow-premium-hover'
                      : 'bg-premium-gradient hover:shadow-premium-hover'
                } text-white`}
                onClick={startTimer}
                disabled={isRunning}
              >
                <div className="relative">
                  <div className="absolute -left-1 -top-1 w-5 h-5 xs:w-6 xs:h-6 sm:w-8 sm:h-8 rounded-full bg-white/10 flex items-center justify-center animate-pulse-slow opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <Play className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
                </div>
                <span className="premium-text text-sm xs:text-base sm:text-lg">Start</span>
              </Button>
              
              <Button
                variant="default"
                className="premium-button col-span-2 xs:col-span-2 sm:col-span-2 button-bounce px-3 py-3 xs:px-4 xs:py-4 sm:px-6 sm:py-6 rounded-xl shadow-lg bg-background border border-primary/20 backdrop-blur-md hover:border-primary/40 hover:bg-background/80 hover:shadow-premium-hover transition-all duration-300 flex items-center justify-center"
                onClick={pauseTimer}
                disabled={!isRunning}
              >
                <Pause className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-primary" />
                <span className="premium-text text-sm xs:text-base sm:text-lg text-foreground">Pause</span>
              </Button>
              
              <Button
                variant="outline"
                className="button-bounce p-3 xs:p-4 sm:p-6 rounded-xl shadow-inner bg-background/40 border border-primary/10 backdrop-blur-sm hover:bg-background/60 hover:border-primary/30 transition-all duration-300 flex items-center justify-center"
                onClick={resetTimer}
              >
                <RotateCcw className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              </Button>
            </div>
          </div>
          
          {/* Timer status indicators */}
          {isRunning && (
            <div className="flex justify-center mt-6">
              <div className="flex items-center space-x-1 px-3 py-1 rounded-full bg-background/30 border border-primary/10">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <span className="text-xs text-muted-foreground premium-text tracking-wider">
                  {timerMode === 'pomodoro' 
                    ? pomodoroState === 'pomodoro' 
                      ? 'FOCUS MODE ACTIVE' 
                      : pomodoroState === 'shortBreak'
                        ? 'SHORT BREAK ACTIVE'
                        : 'LONG BREAK ACTIVE'
                    : timerMode === 'stopwatch'
                      ? 'TRACKING ACTIVE'
                      : 'COUNTDOWN ACTIVE'
                  }
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Timer Complete Modal */}
      {showTimerCompleteModal && (
        <TimerCompleteModal
          onDismiss={() => setShowTimerCompleteModal(false)}
          onStartBreak={handleStartNextSession}
          isBreak={pomodoroState !== "pomodoro"}
          sessionType={pomodoroState}
        />
      )}
    </>
  );
});
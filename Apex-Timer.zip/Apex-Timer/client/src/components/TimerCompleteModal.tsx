import { useEffect } from "react";
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Bell, Coffee, Timer as TimerIcon } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface TimerSettings {
  id: number;
  userId: number | null;
  defaultMinutes: number;
  defaultSeconds: number;
  alarmSound: string;
  volume: number;
  autoStartBreak: boolean;
  timerMode: string;
  pomodoroMinutes: number;
  shortBreakMinutes: number;
  longBreakMinutes: number;
  longBreakInterval: number;
  autoStartPomodoro: boolean;
}

interface TimerCompleteModalProps {
  onDismiss: () => void;
  onStartBreak: () => void;
  isBreak?: boolean;
  sessionType?: "pomodoro" | "shortBreak" | "longBreak";
}

export default function TimerCompleteModal({ 
  onDismiss, 
  onStartBreak, 
  isBreak = false,
  sessionType = "pomodoro" 
}: TimerCompleteModalProps) {
  // Get timer settings
  const { data: timerSettings } = useQuery<TimerSettings>({
    queryKey: ['/api/timer-settings'],
  });

  // Add escape key listener
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        onDismiss();
      }
    };
    
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [onDismiss]);

  // Determine next session name and duration
  const getNextSessionInfo = () => {
    if (isBreak) {
      const mins = timerSettings?.pomodoroMinutes || 25;
      return {
        name: "Start Focus Time",
        time: `${mins}:00`,
        className: "bg-primary hover:bg-primary/80",
        icon: <TimerIcon className="h-4 w-4 mr-2" />
      };
    } else {
      if (sessionType === "pomodoro") {
        const mins = timerSettings?.shortBreakMinutes || 5;
        return {
          name: "Start Short Break",
          time: `${mins}:00`,
          className: "bg-accent hover:bg-accent/80",
          icon: <Coffee className="h-4 w-4 mr-2" />
        };
      } else {
        const mins = timerSettings?.pomodoroMinutes || 25;
        return {
          name: "Start Focus Time",
          time: `${mins}:00`,
          className: "bg-primary hover:bg-primary/80",
          icon: <TimerIcon className="h-4 w-4 mr-2" />
        };
      }
    }
  };

  const nextSession = getNextSessionInfo();
  const isPomodoro = timerSettings?.timerMode === "pomodoro";

  return (
    <Dialog open={true} onOpenChange={() => onDismiss()}>
      <DialogContent className="bg-neutral-900/90 backdrop-blur-lg shadow-xl border-neutral-800 text-white">
        <div className="text-center mb-4">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 pulse-slow">
            <Bell className="h-8 w-8 text-primary animate-pulse" />
          </div>
          <h3 className="text-xl font-bold">Time's Up!</h3>
          <p className="text-neutral-400/80 mt-2">
            {isPomodoro 
              ? isBreak 
                ? "Your break is complete. Ready to focus?" 
                : "Great job! Time for a break."
              : "Your countdown timer has finished."
            }
          </p>
        </div>
        
        <DialogFooter className="flex flex-col sm:flex-row sm:justify-between mt-6 gap-2">
          {isPomodoro && (
            <Button
              onClick={onStartBreak}
              className={`flex-1 button-bounce ${nextSession.className} text-white`}
            >
              {nextSession.icon} {nextSession.name} ({nextSession.time})
            </Button>
          )}
          <Button
            onClick={onDismiss}
            variant="secondary"
            className="flex-1 button-bounce bg-neutral-700 hover:bg-neutral-600 text-white"
          >
            Dismiss
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

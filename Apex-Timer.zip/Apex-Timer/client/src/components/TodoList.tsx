import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import TaskItem from "./TaskItem";
import EditTaskModal from "./EditTaskModal";
import { 
  ListChecks, Check, PlusCircle, 
  Calendar, CheckCircle2, Clock, Activity, 
  BarChart2, Target, Filter 
} from "lucide-react";

type Task = {
  id: number;
  text: string;
  completed: boolean;
  dueDate?: string | null;
  createdAt: string;
};

type TaskFilter = 'all' | 'active' | 'completed';

export default function TodoList() {
  const [newTaskText, setNewTaskText] = useState<string>("");
  const [activeFilter, setActiveFilter] = useState<TaskFilter>('all');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const { toast } = useToast();

  // State for manual task management
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  
  // Function to manually fetch tasks
  const fetchTasks = async () => {
    setIsLoading(true);
    setIsError(false);
    setError(null);
    
    try {
      const response = await fetch('/api/tasks');
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      setTasks(data);
    } catch (err) {
      setIsError(true);
      setError(err instanceof Error ? err : new Error(String(err)));
    } finally {
      setIsLoading(false);
    }
  };
  
  // Initial fetch on component load
  useEffect(() => {
    fetchTasks();
  }, []);

  // States to track loading status for operations
  const [isAdding, setIsAdding] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  // Add task - non real-time implementation
  const addTask = async (text: string) => {
    setIsAdding(true);
    try {
      const response = await fetch("/api/tasks", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ text }),
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      const newTask = await response.json();
      setNewTaskText("");
      toast({
        title: "Task added",
        description: "Your new task has been added. Click refresh to see.",
      });
      
      // Don't automatically update the list - require manual refresh
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to add task: ${error}`,
        variant: "destructive",
      });
    } finally {
      setIsAdding(false);
    }
  };

  // Update task - non real-time implementation
  const updateTask = async (id: number, data: Partial<Task>) => {
    setIsUpdating(true);
    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      const updatedTask = await response.json();
      toast({
        title: "Task updated",
        description: "Task has been updated. Click refresh to see changes.",
      });
      
      // Don't automatically update the list - require manual refresh
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update task: ${error}`,
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  // Delete task - non real-time implementation
  const deleteTask = async (id: number) => {
    setIsDeleting(true);
    try {
      const response = await fetch(`/api/tasks/${id}`, {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      toast({
        title: "Task deleted",
        description: "The task has been removed. Click refresh to update the list.",
      });
      
      // Don't automatically update the list - require manual refresh
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to delete task: ${error}`,
        variant: "destructive",
      });
    } finally {
      setIsDeleting(false);
    }
  };

  // Clear completed tasks - non real-time implementation
  const clearCompletedTasks = async () => {
    setIsClearing(true);
    try {
      const response = await fetch("/api/tasks/completed", {
        method: "DELETE",
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      toast({
        title: "Completed tasks cleared",
        description: "All completed tasks have been removed. Click refresh to update.",
      });
      
      // Don't automatically update the list - require manual refresh
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to clear completed tasks: ${error}`,
        variant: "destructive",
      });
    } finally {
      setIsClearing(false);
    }
  };

  // Filter tasks
  const filteredTasks = tasks.filter(task => {
    if (activeFilter === 'active') return !task.completed;
    if (activeFilter === 'completed') return task.completed;
    return true;
  });

  // Add new task
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskText.trim() === "") return;
    
    addTask(newTaskText);
  };

  // Toggle task status
  const handleToggleTaskStatus = (taskId: number, completed: boolean) => {
    updateTask(taskId, { completed: !completed });
  };

  // Delete task
  const handleDeleteTask = (taskId: number) => {
    deleteTask(taskId);
  };

  // Edit task
  const handleEditTask = (task: Task) => {
    setEditingTask(task);
  };

  // Update task
  const handleUpdateTask = (id: number, text: string, dueDate: string | null) => {
    updateTask(id, { text, dueDate });
    setEditingTask(null);
  };

  // Clear completed tasks
  const handleClearCompleted = () => {
    clearCompletedTasks();
  };
  
  // Function to manually refresh the task list
  const refreshTasks = () => {
    fetchTasks();
    toast({
      title: "Tasks refreshed",
      description: "Your task list has been updated with the latest changes.",
    });
  };

  // Export and import functionality removed
  // Empty placeholder functions to prevent errors
  const handleExportTasks = () => {
    console.log("Export functionality has been removed");
  };
  
  const handleImportTasks = () => {
    console.log("Import functionality has been removed");
  };

  // Get completed count
  const completedCount = tasks.filter(task => task.completed).length;

  return (
    <>
      <div className="mb-4">
        <h2 className="text-2xl font-bold premium-header flex items-center mb-2">
          <ListChecks className="h-6 w-6 mr-2 text-primary" />
          Task Management
        </h2>
        <p className="text-muted-foreground premium-text">Organize your tasks and boost productivity</p>
      </div>
      
      <div className="glass-card mb-8 p-6 rounded-xl shadow-premium relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-1/4 h-full bg-premium-gradient opacity-10 blur-xl"></div>
        
        {/* Add Task Form */}
        <form className="mb-6 relative z-10" onSubmit={handleAddTask}>
          <div className="flex">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="What do you need to accomplish?"
                className="flex-1 bg-background/50 border-primary/20 focus-visible:ring-primary/30 rounded-l-full py-6 pl-12 pr-4 shadow-inner-glow text-foreground"
                value={newTaskText}
                onChange={(e) => setNewTaskText(e.target.value)}
              />
              <PlusCircle className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-primary/70" />
            </div>
            <Button 
              type="submit" 
              className="premium-button rounded-r-full rounded-l-none"
              disabled={isAdding}
            >
              {isAdding ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Adding...
                </span>
              ) : (
                <span className="flex items-center">
                  <Check className="h-4 w-4 mr-2" /> Add Task
                </span>
              )}
            </Button>
          </div>
          <div className="mt-2 text-xs text-muted-foreground flex items-center">
            <Calendar className="h-3 w-3 mr-1" /> 
            <span>Pro tip: Press Enter to add quickly. Add due dates by editing tasks.</span>
          </div>
        </form>
        
        {/* Task Management Bar */}
        <div className="flex flex-wrap justify-between items-center mb-6 pb-4 border-b border-primary/10">
          <div className="flex items-center space-x-1 bg-background/30 rounded-full px-2 py-1 backdrop-blur-sm">
            <Filter className="h-4 w-4 text-primary/80 mr-1" />
            
            <Button
              variant="ghost"
              size="sm"
              className={`rounded-full px-3 py-1 h-auto ${
                activeFilter === 'all' 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'bg-transparent text-muted-foreground hover:text-foreground hover:bg-background/50'
              }`}
              onClick={() => setActiveFilter('all')}
            >
              All
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className={`rounded-full px-3 py-1 h-auto ${
                activeFilter === 'active' 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'bg-transparent text-muted-foreground hover:text-foreground hover:bg-background/50'
              }`}
              onClick={() => setActiveFilter('active')}
            >
              <Clock className="h-3 w-3 mr-1" />
              Active
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className={`rounded-full px-3 py-1 h-auto ${
                activeFilter === 'completed' 
                  ? 'bg-primary text-primary-foreground shadow-sm' 
                  : 'bg-transparent text-muted-foreground hover:text-foreground hover:bg-background/50'
              }`}
              onClick={() => setActiveFilter('completed')}
            >
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Completed
            </Button>
          </div>
          
          <div className="flex items-center mt-2 sm:mt-0">
            <div className="text-sm text-muted-foreground premium-text mr-2 flex items-center">
              <div className="w-20 h-2 bg-background/50 rounded-full overflow-hidden mr-2">
                <div 
                  className="h-full bg-premium-gradient" 
                  style={{ 
                    width: `${tasks.length > 0 ? (completedCount / tasks.length) * 100 : 0}%` 
                  }}
                ></div>
              </div>
              <span className="font-medium">{completedCount}/{tasks.length}</span> completed
            </div>
          </div>
        </div>
        
        {/* Task List */}
        <div className="space-y-3 max-h-[calc(100vh-25rem)] overflow-y-auto pr-1 pb-2 custom-scrollbar">
          {isLoading ? (
            <div className="text-center py-8">
              <div className="w-12 h-12 border-2 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-muted-foreground premium-text">Loading your tasks...</p>
            </div>
          ) : isError ? (
            <div className="text-center py-8 text-destructive glass-card p-4 rounded-lg">
              <div className="premium-text">Error loading tasks: {String(error)}</div>
              <Button variant="outline" size="sm" className="mt-2" onClick={fetchTasks}>
                Try Again
              </Button>
            </div>
          ) : filteredTasks.length === 0 ? (
            <div className="text-center py-12 glass-card rounded-xl p-8 backdrop-blur-sm">
              <div className="w-16 h-16 rounded-full bg-premium-gradient flex items-center justify-center mx-auto mb-4 opacity-80">
                <ListChecks className="h-8 w-8 text-primary-foreground" /> 
              </div>
              <h3 className="text-lg font-semibold mb-2 premium-header">No {activeFilter !== 'all' ? activeFilter : ''} tasks yet</h3>
              <p className="text-muted-foreground premium-text max-w-xs mx-auto mb-4">
                {activeFilter === 'all' 
                  ? "Your task list is empty. Add your first task to get started." 
                  : activeFilter === 'active' 
                    ? "You don't have any active tasks. Add a new task or mark some as incomplete."
                    : "You don't have any completed tasks yet. Complete tasks to see them here."}
              </p>
              {activeFilter !== 'all' && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="bg-background/20 border-primary/20 hover:bg-background/40"
                  onClick={() => setActiveFilter('all')}
                >
                  Show All Tasks
                </Button>
              )}
            </div>
          ) : (
            <>
              <div className="animate-slide-in-up">
                {filteredTasks.map(task => (
                  <TaskItem
                    key={task.id}
                    task={task}
                    onToggleStatus={() => handleToggleTaskStatus(task.id, task.completed)}
                    onEdit={() => handleEditTask(task)}
                    onDelete={() => handleDeleteTask(task.id)}
                  />
                ))}
              </div>
            </>
          )}
        </div>
        
        {/* Task List Actions */}
        <div className="flex flex-wrap justify-between items-center mt-6 pt-4 border-t border-primary/10">
          <div className="flex space-x-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-sm text-muted-foreground hover:text-foreground hover:bg-background/40"
              onClick={handleClearCompleted}
              disabled={completedCount === 0 || isClearing}
            >
              {isClearing ? (
                <span className="flex items-center">
                  <svg className="animate-spin h-3 w-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Clearing...
                </span>
              ) : (
                <>
                  <Check className="h-3 w-3 mr-1" /> Clear completed
                </>
              )}
            </Button>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            className="text-sm bg-primary/10 hover:bg-primary/20 border-primary/30"
            onClick={refreshTasks}
            disabled={isLoading}
          >
            {isLoading ? (
              <span className="flex items-center">
                <svg className="animate-spin h-3 w-3 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Refreshing...
              </span>
            ) : (
              <>
                <svg className="h-3 w-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                Refresh Tasks
              </>
            )}
          </Button>
        </div>
      </div>
      
      {/* Productivity Stats */}
      <div className="glass-card p-6 rounded-xl shadow-premium overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full bg-premium-gradient opacity-5"></div>
        
        <div className="relative z-10">
          <h2 className="text-xl font-bold premium-header mb-4 flex items-center">
            <Activity className="h-5 w-5 mr-2 text-primary" />
            Productivity Insights
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-background/40 rounded-xl p-4 shadow-inner-glow flex items-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center bg-primary/10 mr-4">
                <CheckCircle2 className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-muted-foreground text-sm mb-1">Tasks Completed</p>
                <p className="text-2xl font-bold premium-header">{completedCount}</p>
              </div>
            </div>
            
            <div className="bg-background/40 rounded-xl p-4 shadow-inner-glow flex items-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center bg-primary/10 mr-4">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-muted-foreground text-sm mb-1">Focus Time</p>
                <p className="text-2xl font-bold premium-header">25:00</p>
              </div>
            </div>
            
            <div className="bg-background/40 rounded-xl p-4 shadow-inner-glow flex items-center">
              <div className="w-12 h-12 rounded-full flex items-center justify-center bg-primary/10 mr-4">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-muted-foreground text-sm mb-1">Completion Rate</p>
                <p className="text-2xl font-bold premium-header">
                  {tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Edit Task Modal */}
      {editingTask && (
        <EditTaskModal
          task={editingTask}
          onSave={handleUpdateTask}
          onCancel={() => setEditingTask(null)}
        />
      )}
    </>
  );
}
